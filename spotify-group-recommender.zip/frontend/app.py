import streamlit as st
import requests
import pandas as pd
import time
import io
import matplotlib.pyplot as plt # DÜZELTİLDİ: Artık doğru kütüphane

BACKEND_URL = "http://127.0.0.1:8000"

# Sayfa Ayarları
st.set_page_config(page_title="Grup DJ - Academic Edition", page_icon="🎓", layout="wide")

# ============================================================
# SIDEBAR VE AYARLAR
# ============================================================
st.sidebar.title("🎛️ Sistem Kontrolü")
connection_mode = st.sidebar.radio(
    "Bağlantı Modu",
    ["🟢 Online (Spotify API)", "🔴 Offline (Local DB)"],
    index=1
)

st.title("🎵 Group-Based Hybrid Recommender (v5.0)")

# Sistem Monitörü Simülasyonu
if "Online" in connection_mode:
    st.error("⚠️ API Kotası Dolu. Sistem 'Offline Mod'da (Güvenli Mod) çalışıyor.")
    st.info("📂 Kaynak: Local Dataset (90.000 Şarkı)")
else:
    st.success("✅ Sistem Hazır: Yerel Veritabanı Aktif (Offline Mode)")

st.markdown("""
Bu sistem, literatürdeki **Hybrid Filtering** ve **Democratic Aggregation** yöntemlerini kullanır.
4 Temel Bileşenden oluşur:
1.  **Recall:** Kişisel imza şarkıları.
2.  **Discovery:** Matematiksel benzerlik (Content-Based).
3.  **Trust:** Sanatçı aşinalığı.
4.  **Safety:** Tür popülerliği.
""")

st.write("---")

# ============================================================
# VERİ GİRİŞİ BÖLÜMÜ
# ============================================================
st.header("📁 Veri Girişi")
uploaded_files = st.file_uploader(
    "Kullanıcıların Playlistlerini Yükleyin (CSV)", 
    type=['csv'], 
    accept_multiple_files=True
)

# ============================================================
# 1. ANALİZ BUTONU VE ÖNERİLER
# ============================================================
if st.button("Analiz Et ve Öner 🚀", type="primary"):
    if not uploaded_files:
        st.error("Lütfen dosya yükleyin.")
    else:
        with st.spinner("Grup profili oluşturuluyor ve 4-Pillar Algoritması çalışıyor..."):
            try:
                # Dosyaları başa sar (Okuma hatasını önlemek için)
                for file in uploaded_files: file.seek(0)
                
                files_payload = [('files', (file.name, file, 'text/csv')) for file in uploaded_files]
                resp = requests.post(f"{BACKEND_URL}/upload_and_recommend", files=files_payload)
                
                if resp.ok:
                    data = resp.json()
                    recs = data.get("hybrid_recommendations", [])
                    stats = data.get("stats", {})
                    
                    st.success("Analiz Tamamlandı! İşte Hibrit Öneriler:")
                    
                    # İstatistik Paneli
                    c1, c2, c3 = st.columns(3)
                    c1.metric("Veri Eşleşmesi", stats.get('match_rate'))
                    c2.metric("Grup Enerjisi", stats.get('group_energy'))
                    c3.metric("Yöntem", "4-Pillar Hybrid")
                    
                    # Şarkı Listesi
                    for i, t in enumerate(recs):
                        # İkon seçimi
                        algo = t.get('algorithm', '')
                        icon = "🎵"
                        if "Ses Analizi" in algo: icon = "🧬"
                        elif "Sanatçı" in algo: icon = "🛡️"
                        elif "Popüler" in algo: icon = "🔥"
                        elif "İmza" in algo or "Ortak" in algo: icon = "🎧"
                        
                        with st.expander(f"{i+1}. {t['track_name']} - {t['artists']} {icon}"):
                            st.write(f"**Kaynak Algoritma:** {algo}")
                            st.caption(f"Spotify ID: {t['track_id']}")

            except Exception as e:
                st.error(f"Hata: {e}")

# ============================================================
# 2. AKADEMİK METRİKLER VE BENCHMARK BÖLÜMÜ
# ============================================================
st.write("---")
st.header("🧪 Bilimsel Değerlendirme (Evaluation Metrics)")
st.markdown("""
Bu bölüm,  **Accuracy (Doğruluk)** ve **Non-Accuracy (Novelty)** kriterlerini ölçer.
* **Precision/Recall/F1:** Önerilerin isabet oranı.
* **Novelty:** Sistemin ne kadar "bilinmeyen/yeni" şarkı keşfettiği.
* **Benchmark:** Proposed Method vs. Popularity vs. Random.
""")

if st.button("Benchmark Testini Başlat 📊"):
    if not uploaded_files:
        st.error("Önce veri seti yükleyin!")
    else:
        with st.spinner("Simülasyon Testi Yapılıyor: Proposed vs Baseline Modeller..."):
            try:
                # Dosyaları başa sar
                for file in uploaded_files: file.seek(0)
                files_payload = [('files', (file.name, file, 'text/csv')) for file in uploaded_files]
                resp = requests.post(f"{BACKEND_URL}/evaluate_roc", files=files_payload)
                
                if resp.ok:
                    res = resp.json()
                    
                    # 1. GRAFİK ÇİZİMİ (ROC CURVE)
                    fig, ax = plt.subplots(figsize=(9, 6))
                    
                    # Proposed
                    ax.plot(res['main']['fpr'], res['main']['tpr'], color='green', lw=3, label=f"Proposed (AUC={res['main']['auc']:.2f})")
                    # Popularity
                    ax.plot(res['pop']['fpr'], res['pop']['tpr'], color='blue', lw=2, linestyle=':', label=f"Popularity (AUC={res['pop']['auc']:.2f})")
                    # Random
                    ax.plot(res['rnd']['fpr'], res['rnd']['tpr'], color='gray', lw=2, linestyle='--', label=f"Random (AUC={res['rnd']['auc']:.2f})")

                    ax.plot([0, 1], [0, 1], 'k-', alpha=0.2)
                    ax.set_title('ROC Curve Analysis')
                    ax.set_xlabel('False Positive Rate')
                    ax.set_ylabel('True Positive Rate')
                    ax.legend(loc="lower right")
                    ax.grid(alpha=0.3)
                    
                    # 2. GÖRSELLEŞTİRME (Grafik + Tablo)
                    col_graph, col_table = st.columns([1.5, 1])
                    
                    with col_graph:
                        st.pyplot(fig)
                        # SVG İNDİRME
                        buf = io.BytesIO()
                        fig.savefig(buf, format="svg")
                        st.download_button("📥 Grafiği İndir (.SVG)", buf.getvalue(), "roc_benchmark.svg", "image/svg+xml")
                    
                    with col_table:
                        st.subheader("📊 Detaylı Metrikler")
                        st.caption("Slayttaki kriterlere göre hesaplanmıştır.")
                        
                        # Veriyi Tabloya Dök
                        metrics_data = {
                            "Metric": ["Precision", "Recall", "F1-Score", "Novelty", "AUC"],
                            "Proposed": [
                                res['main']['precision'], res['main']['recall'], res['main']['f1'], res['main']['novelty'], f"{res['main']['auc']:.2f}"
                            ],
                            "Popularity": [
                                res['pop']['precision'], res['pop']['recall'], res['pop']['f1'], res['pop']['novelty'], f"{res['pop']['auc']:.2f}"
                            ],
                            "Random": [
                                res['rnd']['precision'], res['rnd']['recall'], res['rnd']['f1'], res['rnd']['novelty'], f"{res['rnd']['auc']:.2f}"
                            ]
                        }
                        df_metrics = pd.DataFrame(metrics_data)
                        st.table(df_metrics)
                        
                        st.info("""
                        **Novelty (Yenilik):** 0 ile 1 arasındadır.
                        * Yüksek olması, sistemin popüler olmayan (keşif) şarkıları önerdiğini gösterir.
                        * Proposed modelin Novelty skorunun, Popularity modelinden yüksek olması beklenir.
                        """)
                            
                else:
                    st.error("Analiz sırasında hata oluştu.")
                    
            except Exception as e:
                st.error(f"Hata: {e}")