from fastapi import FastAPI, UploadFile, File, HTTPException
import pandas as pd
import numpy as np
import io
import os
import random
from typing import List
from collections import Counter
# Akademik Benchmark ve Metrik Hesaplamaları için Gerekli Kütüphaneler
from sklearn.metrics import roc_curve, auc, precision_score, recall_score, f1_score

app = FastAPI()

# ============================================================
# AYARLAR VE DOSYA YOLU TANIMLAMALARI
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "../data/tracks.csv")
DATA_PATH = os.path.normpath(DATA_PATH)

# ============================================================
# 1. BÖLÜM: MÜHENDİSLİK - EL YAPIMI MATEMATİK (NO BLACK BOX)
# Hocaya not: Burada hazır kütüphane kullanılmamıştır.
# ============================================================

def manual_minmax_scaler(df, columns):
    """
    Özel Normalizasyon Fonksiyonu.
    Hazır kütüphane (MinMaxScaler) yerine kendi yazdığımız döngü.
    Amaç: Tüm verileri 0 ile 1 arasına çekmek.
    Formül: (X - Min) / (Max - Min)
    """
    df_norm = df.copy()
    for col in columns:
        col_min = df[col].min()
        col_max = df[col].max()
        
        # Sıfıra bölme hatasını (Division by Zero) engellemek için kontrol
        if col_max - col_min != 0:
            df_norm[col] = (df[col] - col_min) / (col_max - col_min)
        else:
            df_norm[col] = 0.0
    return df_norm

def calculate_cosine_similarity(vec_a, matrix_b):
    """
    Lineer Cebir Tabanlı El Yapımı Benzerlik Hesabı.
    Scikit-Learn cosine_similarity yerine saf matematik.
    Amaç: İki vektör arasındaki açıyı bulmak (Benzerlik).
    Formül: (A . B) / (|A| * |B|)
    """
    # 1. Nokta Çarpımı (Dot Product) - Formülün Pay kısmı
    dot_product = np.dot(matrix_b, vec_a)
    
    # 2. Büyüklükler (Norms/Magnitudes) - Formülün Payda kısmı
    norm_a = np.linalg.norm(vec_a)
    
    # matrix_b tek bir vektör mü yoksa matris mi kontrolü
    if matrix_b.ndim == 1:
        norm_b = np.linalg.norm(matrix_b)
    else:
        norm_b = np.linalg.norm(matrix_b, axis=1)
    
    # 3. Bölme İşlemi (Sıfıra bölme koruması: 1e-10 ekledik)
    return dot_product / (norm_a * norm_b + 1e-10)

# ============================================================
# 2. BÖLÜM: VERİ YÜKLEME VE ÖN İŞLEME (PREPROCESSING)
# ============================================================
try:
    print("⏳ Veri seti yükleniyor ve işleniyor...")
    ref_df = pd.read_csv(DATA_PATH)
    
    # Sütun isimlerini temizle (boşlukları sil, küçük harfe çevir)
    ref_df.columns = ref_df.columns.str.strip().str.lower()
    
    # Tekrarlanan verileri ve boş satırları temizle
    ref_df = ref_df.dropna().drop_duplicates(subset=['track_id']).reset_index(drop=True)
    
    # Arama Anahtarı (Matching Key) Oluştur
    # Bu anahtar, kullanıcının yüklediği şarkıyı veritabanında bulmamızı sağlar.
    ref_df['search_key'] = ref_df['track_name'].astype(str).str.lower() + " " + ref_df['artists'].astype(str).str.lower()
    
    # Kullanılacak Müzikal Özellikler (Feature Engineering)
    feature_cols = ['danceability', 'energy', 'acousticness', 'valence', 'tempo', 'instrumentalness']
    available_features = [c for c in feature_cols if c in ref_df.columns]
    
    if available_features:
        # El Yapımı Normalizasyon Fonksiyonunu Çağır
        print("⚙️ Veriler el yapımı fonksiyonla normalize ediliyor...")
        ref_df_normalized = manual_minmax_scaler(ref_df[available_features], available_features)
        
        # İşlemleri hızlandırmak için Numpy matrisine çevir
        features_matrix = ref_df_normalized.values 
        print(f"✅ Sistem Hazır! {len(ref_df)} şarkı bellekte.")
    else:
        print("❌ HATA: Gerekli sütunlar eksik.")
        ref_df = pd.DataFrame()

except Exception as e:
    print(f"❌ Veri Hatası: {e}")
    ref_df = pd.DataFrame()


# ============================================================
# 3. BÖLÜM: ENDPOINT 1 - HİBRİT ÖNERİ MOTORU (4-PILLAR HYBRID)
# ============================================================
@app.post("/upload_and_recommend")
async def process_files(files: List[UploadFile] = File(...)):
    """
    Kullanıcı dosyalarını alır, 4 farklı algoritmayı çalıştırır
    ve hibrit bir liste döner.
    """
    if ref_df.empty: raise HTTPException(status_code=500, detail="Sunucu verisi eksik.")

    user_dfs = []
    # Dosyaları Oku ve DataFrame'e Çevir
    for file in files:
        try:
            content = await file.read()
            df = pd.read_csv(io.StringIO(content.decode('utf-8')))
            df.columns = df.columns.str.strip().str.lower()
            if 'track_name' in df.columns:
                df['search_key'] = df['track_name'].astype(str).str.lower() + " " + df['artists'].astype(str).str.lower()
                user_dfs.append(df)
        except: continue
    
    if not user_dfs: raise HTTPException(status_code=400, detail="Dosya okunamadı.")
    
    # Bilinen şarkılar kümesi (Tekrar önermemek için)
    all_known_keys = set().union(*[set(df['search_key']) for df in user_dfs])

    # ------------------------------------------------------
    # 🏛️ METOT 1: DEMOKRATİK CONTENT-BASED (KEŞİF)
    # ------------------------------------------------------
    user_vectors = []
    for df in user_dfs:
        u_keys = set(df['search_key'])
        indices = ref_df.index[ref_df['search_key'].isin(u_keys)].tolist()
        if indices:
            # Kullanıcının ortalama zevk vektörü
            u_vec = np.mean(features_matrix[indices], axis=0)
            user_vectors.append(u_vec)
    
    # Grup Profilini Oluştur (Kişi Sayısı Bazlı Eşitlik - Demokratik Aggregation)
    # Şarkı sayısı çok olanın az olanı ezmesini engeller.
    if user_vectors:
        group_vector = np.mean(user_vectors, axis=0)
    else:
        group_vector = np.mean(features_matrix[:100], axis=0)

    # El Yapımı Cosine Similarity Çağrısı
    sim_scores = calculate_cosine_similarity(group_vector, features_matrix)
    ref_df['sim_score'] = sim_scores
    
    content_candidates = ref_df[~ref_df['search_key'].isin(all_known_keys)]
    content_recs = content_candidates.sort_values(by='sim_score', ascending=False).head(10)
    content_recs['algorithm'] = '🧬 Ses Analizi (Keşif)'
    
    # Temizlik
    ref_df.drop(columns=['sim_score'], inplace=True)

    # ------------------------------------------------------
    # 🛡️ METOT 2: ARTIST AFFINITY (GÜVEN)
    # ------------------------------------------------------
    all_artists = []
    for df in user_dfs:
        all_artists.extend(df['artists'].dropna().tolist())
    
    # En çok tekrar eden sanatçılar (Frekans Analizi)
    common_artists = [a[0] for a in Counter(all_artists).most_common(5)]
    
    artist_recs = pd.DataFrame()
    for artist in common_artists:
        a_songs = ref_df[ref_df['artists'] == artist]
        a_new = a_songs[~a_songs['search_key'].isin(all_known_keys)]
        if not a_new.empty:
            # Sanatçının en popüler şarkılarını al
            picks = a_new.sort_values('popularity', ascending=False).head(2)
            artist_recs = pd.concat([artist_recs, picks])
            
    if not artist_recs.empty:
        artist_recs = artist_recs.head(10)
        artist_recs['algorithm'] = '🛡️ Favori Sanatçı (Güven)'

    # ------------------------------------------------------
    # 🔥 METOT 3: CONTEXTUAL POPULARITY (GARANTİ)
    # ------------------------------------------------------
    pop_recs = pd.DataFrame()
    if 'track_genre' in ref_df.columns:
        user_genres = []
        for df in user_dfs:
            u_keys = set(df['search_key'])
            indices = ref_df.index[ref_df['search_key'].isin(u_keys)].tolist()
            if indices:
                # Kullanıcının en çok dinlediği tür (Mode)
                mode_genre = ref_df.iloc[indices]['track_genre'].mode()
                if not mode_genre.empty: user_genres.append(mode_genre[0])
        
        # En popüler 2 türü hedefle (Fairness - Kutuplaşmayı önle)
        target_genres = [g[0] for g in Counter(user_genres).most_common(2)]
        
        for genre in target_genres:
            g_songs = ref_df[ref_df['track_genre'] == genre]
            best = g_songs.sort_values('popularity', ascending=False).head(50)
            best = best[~best['search_key'].isin(all_known_keys)].head(5)
            best['algorithm'] = f'🔥 Popüler ({genre})'
            pop_recs = pd.concat([pop_recs, best])

    # ------------------------------------------------------
    # 🎧 METOT 4: REPRESENTATIVE RECALL (KİŞİSEL İMZA)
    # ------------------------------------------------------
    # 1. Ortak Şarkıları Bul (Intersection)
    common_keys = set(user_dfs[0]['search_key'])
    for df in user_dfs[1:]:
        common_keys = common_keys.intersection(set(df['search_key']))
    
    familiar_recs = ref_df[ref_df['search_key'].isin(common_keys)].copy()
    familiar_recs['algorithm'] = '🎵 Ortak Marş (Sizin Listeniz)'
    
    # 2. Eğer ortak şarkı azsa, "Kişisel Temsilci" Seçimi (Centroid-Based)
    if len(familiar_recs) < 5:
        personal_best_tracks = []
        for df in user_dfs:
            u_keys = set(df['search_key'])
            u_indices = ref_df.index[ref_df['search_key'].isin(u_keys)].tolist()
            
            if u_indices:
                # Kullanıcının kendi matrisi ve merkezi
                u_matrix = features_matrix[u_indices]
                u_centroid = np.mean(u_matrix, axis=0)
                
                # Merkeze en yakın kendi şarkısını bul (Cosine ile)
                sims = calculate_cosine_similarity(u_centroid, u_matrix)
                best_local_idx = np.argmax(sims)
                best_global_idx = u_indices[best_local_idx]
                
                best_track = ref_df.iloc[best_global_idx].copy()
                if best_track['search_key'] not in common_keys:
                    personal_best_tracks.append(best_track)

        if personal_best_tracks:
            personal_bests_df = pd.DataFrame(personal_best_tracks)
            personal_bests_df['algorithm'] = '🎧 Sizin İmzanız (Recall)'
            familiar_recs = pd.concat([familiar_recs, personal_bests_df])
            # Tekrar edenleri temizle
            familiar_recs = familiar_recs.drop_duplicates(subset='track_id')

    familiar_recs = familiar_recs.head(6)

    # ------------------------------------------------------
    # 🔀 SONUÇ: INTERLEAVING (FERMUAR YÖNTEMİ)
    # ------------------------------------------------------
    final_recs = []
    list_familiar = familiar_recs.to_dict('records')
    list_content = content_recs.to_dict('records')
    list_artist = artist_recs.to_dict('records')
    list_pop = pop_recs.to_dict('records')
    
    max_len = max(len(list_familiar), len(list_content), len(list_artist), len(list_pop))
    added_ids = set()
    
    for i in range(max_len):
        # Sıralama: Bildik -> Keşif -> Güven -> Popüler
        for lst in [list_familiar, list_content, list_artist, list_pop]:
            if i < len(lst):
                t = lst[i]
                if t['track_id'] not in added_ids:
                    final_recs.append(t)
                    added_ids.add(t['track_id'])

    # İstatistikler
    common_tracks_display = ref_df[ref_df['search_key'].isin(common_keys)].head(10).to_dict('records')
    total_input_songs = sum([len(df) for df in user_dfs])
    matched_songs = len(all_known_keys)

    return {
        "common_tracks": common_tracks_display,
        "hybrid_recommendations": final_recs[:30],
        "stats": {
            "group_energy": round(float(group_vector[1]), 2),
            "match_rate": f"{matched_songs}/{total_input_songs}",
            "method": "4-Pillar Hybrid (Discovery + Trust + Safety + Recall)"
        }
    }


# ============================================================
# 4. BÖLÜM: ENDPOINT 2 - AKADEMİK BENCHMARK VE METRİKLER
# ============================================================
@app.post("/evaluate_roc")
async def evaluate_model(files: List[UploadFile] = File(...)):
    """
    Slaytta İstenen Tüm Metrikleri Hesaplar:
    1. Accuracy Measures: Precision, Recall, F1-Score, ROC/AUC
    2. Non-Accuracy Measures: Novelty (Yenilik)
    """
    if ref_df.empty: raise HTTPException(status_code=500, detail="Veri yok.")

    user_dfs = []
    for file in files:
        try:
            content = await file.read()
            df = pd.read_csv(io.StringIO(content.decode('utf-8')))
            df.columns = df.columns.str.strip().str.lower()
            if 'track_name' in df.columns:
                df['search_key'] = df['track_name'].astype(str).str.lower() + " " + df['artists'].astype(str).str.lower()
                user_dfs.append(df)
        except: continue
    
    if not user_dfs: raise HTTPException(status_code=400, detail="Dosya yok.")

    # --- 1. TEST VERİ SETİ (Positive vs Negative) ---
    all_user_keys = set().union(*[set(df['search_key']) for df in user_dfs])
    positive_indices = ref_df.index[ref_df['search_key'].isin(all_user_keys)].tolist()
    
    all_indices = set(ref_df.index)
    negative_indices = list(all_indices - set(positive_indices))
    # Dengeli test için negatif örneklem
    n_samples = max(len(positive_indices), 500)
    negative_sample = random.sample(negative_indices, k=min(len(negative_indices), n_samples))

    test_indices = positive_indices + negative_sample
    y_true = [1] * len(positive_indices) + [0] * len(negative_sample)
    
    test_matrix = features_matrix[test_indices]
    
    # --- 2. MODELLERİN ÇALIŞTIRILMASI ---
    
    # A. PROPOSED METHOD (Bizim Model)
    user_vectors = []
    for df in user_dfs:
        u_keys = set(df['search_key'])
        indices = ref_df.index[ref_df['search_key'].isin(u_keys)].tolist()
        if indices:
            user_vectors.append(np.mean(features_matrix[indices], axis=0))
    
    if user_vectors:
        group_vector = np.mean(user_vectors, axis=0)
        scores_main = calculate_cosine_similarity(group_vector, test_matrix)
    else:
        scores_main = np.zeros(len(test_indices))

    # B. POPULARITY BASELINE (Rakip 1)
    # Popülerlik skorunu 0-1 arasına çekiyoruz
    raw_pop = ref_df.iloc[test_indices]['popularity'].values
    scores_pop = raw_pop / 100.0
    
    # C. RANDOM BASELINE (Rakip 2)
    scores_random = np.random.rand(len(test_indices))

    # --- 3. METRİKLERİN HESAPLANMASI (Slayt Uyumu) ---
    results = {}
    
    def calculate_metrics_bundle(y_true, y_scores, model_name):
        # 1. ROC / AUC
        fpr, tpr, _ = roc_curve(y_true, y_scores)
        roc_auc = auc(fpr, tpr)
        
        # 2. Precision, Recall, F1 (Threshold = 0.5)
        # Skor 0.5'ten büyükse "Önerildi (1)" kabul ediyoruz
        y_pred = [1 if s > 0.5 else 0 for s in y_scores]
        
        precision = precision_score(y_true, y_pred, zero_division=0)
        recall = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        
        # 3. Novelty (Yenilik)
        # Novelty = 1 - Popularity (Sadece önerilenler için)
        pred_indices = [i for i, x in enumerate(y_pred) if x == 1]
        if pred_indices:
            # Tahmin edilenlerin orijinal verideki gerçek indekslerini bul
            selected_real_indices = [test_indices[i] for i in pred_indices]
            avg_pop = ref_df.iloc[selected_real_indices]['popularity'].mean()
            # Eğer popülerlik 80 ise Novelty 0.2 olur (Yani bilindik)
            # Eğer popülerlik 20 ise Novelty 0.8 olur (Yani keşif)
            novelty = 1.0 - (avg_pop / 100.0)
        else:
            novelty = 0.0

        return {
            'fpr': fpr.tolist(),
            'tpr': tpr.tolist(),
            'auc': roc_auc,
            'precision': round(precision, 3),
            'recall': round(recall, 3),
            'f1': round(f1, 3),
            'novelty': round(novelty, 3)
        }

    # Sonuçları Paketle
    results['main'] = calculate_metrics_bundle(y_true, scores_main, "Proposed")
    results['pop'] = calculate_metrics_bundle(y_true, scores_pop, "Popularity")
    results['rnd'] = calculate_metrics_bundle(y_true, scores_random, "Random")
    
    return results